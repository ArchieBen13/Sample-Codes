# Employee-Salary-Payroll-System
INTRODUCTION

Salary Management System is the heart of any Human Resource System of an organization. The solution has to take care of the calculation of salary as per rules of the company, income tax calculation and various deductions to be done from the salary including statutory deductions like Income tax and provident fund deductions. It has to generate pay-slip, cheque summary and MIS reports. 

It is understood that we are tired of managing thousands of odd papers, pay slips, payroll reports, and salary details and so on. Imagine that we have a payroll processing system which will generate our pay slips and payroll reports within seconds. We can help others automated your payroll system by developing a customized payroll application that suits your specific requirements.


PURPOSE

Main aim of developing Employee Payroll Management is to provide an easy way not only to automate all functionalities involved managing leaves and Payroll for the employees of Company, but also to provide full functional reports to management of Company with the details about usage of leave facility and Salaries paid or to be paid to employees.
We are committed to bring the best way of management in the various forms of EPM. We understand that EPM in not just a product to be sold, it is a tool to manage the inner operation of Company related to employee leave and Payroll. 


SCOPE

This Application works in Multiple PC’s installed on multiple Computers by sharing same database by which users of different department can use it sitting at different locations simultaneously.
Further, it can be easily customized for the use of any other type of firm. This project will help them to create a working system into the latest concept of paperless office.

Existing System

Presently salary calculation is done manually, it takes so much of time to compose salary of all employees. It also takes very long time to make salary slip ready. Due to manual process some time it takes very long time, in turn it delays the salary distribution. This is a big problem to manage when salary is not generated in time. Even with double cross check here or there some errors will happen, this again create large problem. To solve all this the organization, require very good software to take care of all these.


Proposed System

The proposed software will solve all the problems they are facing now. This software is designed such way that it will generate the salary every month in time. So there not much worries. This software also equipped with to enter the allowance and deductions of each employee in the organization, it help them to track each employee net salary, based on this we can generate the salary slip . The software built to generate individual pay slip and summary of the payroll
